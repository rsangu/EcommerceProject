package com.cbt.configserverboot3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Configserverboot3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
