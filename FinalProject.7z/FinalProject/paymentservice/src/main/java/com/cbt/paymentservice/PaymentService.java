package com.cbt.paymentservice;

public interface PaymentService {

    long doPayment(PaymentRequest paymentRequest);
    PaymentResponse getPaymentDetailsByOrderId(long orderId);
}
