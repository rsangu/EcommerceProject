package com.cbt.orderservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@FeignClient(name="productservice")
public interface ProductClient {

    @GetMapping("/Products/{id}")
    Product getProductById(@PathVariable String id);
}
