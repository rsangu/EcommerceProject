package com.cbt.gatewayserverboot3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gatewayserverboot3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
