package com.cbt.inventoryservice;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity(name = "Inventory")
public class Inventory {

    @Id
    private String productId;
    private int quantity;

    public String getProductId() {
        return productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


}
