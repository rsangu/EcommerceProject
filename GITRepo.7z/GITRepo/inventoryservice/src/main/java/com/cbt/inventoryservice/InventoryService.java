package com.cbt.inventoryservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;

    public List<Inventory> getAllInventory(){
        return inventoryRepository.findAll();
    }

    public Inventory getInventoryByProductId(@PathVariable String productId){
        return inventoryRepository.findById(productId).orElse(null);
    }

    public Inventory addInventory(Inventory inventory){
        return inventoryRepository.save(inventory);
    }

    public Inventory updateInventory(String productId, int quantity){
        Inventory inventory = inventoryRepository.findById(productId).orElseThrow(()->new RuntimeException("Product Id not found"));
        inventory.setQuantity(quantity);
        return inventoryRepository.save(inventory);
    }
}
