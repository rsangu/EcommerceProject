package com.cbt.inventoryservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Inventory")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    @GetMapping
    public List<Inventory> getAllInventory(){
        return inventoryService.getAllInventory();
    }

    @GetMapping("/{productId}")
    public Inventory getInventoryByProductId(@PathVariable String productId){
        return inventoryService.getInventoryByProductId(productId);
    }

    @PostMapping("/create")
    public Inventory createInventory(@RequestBody Inventory inventory) {
        return inventoryService.addInventory(inventory);
    }

    @PutMapping("/{productId}")
    public Inventory updateInventory(@PathVariable String productId, @RequestParam(value = "quantity", defaultValue = "0") Integer quantity ){
        return inventoryService.updateInventory(productId, quantity);
    }

    @GetMapping("/welcome")
    public String welcome(){
        return "welcome to inventory service";
    }

}
